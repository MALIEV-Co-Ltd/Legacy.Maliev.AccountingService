using Legacy.Maliev.AccountingService.Application.Interfaces;
using Legacy.Maliev.AccountingService.Application.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text.Json;

namespace Legacy.Maliev.AccountingService.Api.Controllers;

public abstract class CrudController<T>(IAccountingService service, IIdempotencyStore idempotency) : ControllerBase where T : class
{
    protected IAccountingService Service { get; } = service;

    protected async Task<ActionResult<T>> Create(string scope, T item, string route, object routeValues, string? key, CancellationToken cancellationToken)
    {
        if (!string.IsNullOrWhiteSpace(key))
        {
            var issuers = User.FindAll("iss").Select(claim => claim.Value).ToArray();
            var subjects = User.FindAll("sub").Select(claim => claim.Value).ToArray();
            if (subjects.Length == 0)
            {
                subjects = User.FindAll(ClaimTypes.NameIdentifier).Select(claim => claim.Value).ToArray();
            }
            if (User.Identity?.IsAuthenticated != true || issuers.Length != 1 || subjects.Length != 1
                || string.IsNullOrWhiteSpace(issuers[0]) || string.IsNullOrWhiteSpace(subjects[0]))
            {
                return Forbid();
            }

            // Frame both signed identity fields before hashing; never read an unbound legacy memo.
            var identity = JsonSerializer.SerializeToUtf8Bytes(new[] { issuers[0], subjects[0] });
            scope = $"{scope}:caller-v1:{Convert.ToHexString(SHA256.HashData(identity))}";
        }
        var value = await IdempotentCreates.GetOrCreateAsync(idempotency, scope, key,
            () => Service.CreateAsync(item, cancellationToken), cancellationToken);
        var values = new RouteValueDictionary(routeValues);
        var routeParameter = values.Keys.Single();
        values[routeParameter] = typeof(T).GetProperty("Id")?.GetValue(value);
        return CreatedAtRoute(route, values, value);
    }

    protected async Task<IActionResult> Delete(int id, CancellationToken cancellationToken) =>
        await Service.DeleteAsync<T>(id, cancellationToken) ? NoContent() : NotFound();

    protected async Task<ActionResult<T>> Get(int id, CancellationToken cancellationToken)
    {
        var value = await Service.GetAsync<T>(id, cancellationToken);
        return value is null ? NotFound() : value;
    }

    protected async Task<ActionResult<IReadOnlyList<T>>> List(CancellationToken cancellationToken)
    {
        var items = await Service.ListAsync<T>(cancellationToken);
        return items.Count == 0 ? NotFound() : Ok(items);
    }

    protected async Task<IActionResult> Update(int id, T item, DateTimeOffset? expected, CancellationToken cancellationToken) =>
        await Service.UpdateAsync(id, item, expected, cancellationToken) switch
        {
            UpdateResult.Updated => NoContent(),
            UpdateResult.NotFound => NotFound(),
            _ => Conflict(),
        };
}
