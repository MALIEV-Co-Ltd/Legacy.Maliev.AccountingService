using System.Text.RegularExpressions;

using YamlDotNet.Core;
using YamlDotNet.RepresentationModel;

namespace Legacy.Maliev.AccountingService.Tests.Workflows;

public sealed class WorkflowContractTests
{
    private static readonly string Workflow = File.ReadAllText(FindRepositoryFile(".github", "workflows", "_build-and-test.yml"));
    private static readonly string ApiProject = File.ReadAllText(
        FindRepositoryFile("Legacy.Maliev.AccountingService.Api", "Legacy.Maliev.AccountingService.Api.csproj"));
    private static readonly string DataProject = File.ReadAllText(
        FindRepositoryFile("Legacy.Maliev.AccountingService.Data", "Legacy.Maliev.AccountingService.Data.csproj"));

    [Fact]
    public void BuildAndTest_SatisfiesStructuralContract()
    {
        WorkflowContractValidator.Validate(Workflow);
        AssertMutationRejected("python3 -B scripts/verify-employee-completion.py runner-results --full", "echo omitted native employee gate");
        AssertMutationRejected("python3 -B scripts/verify-file-metadata.py runner-results --full", "echo omitted native file metadata gate");
        AssertMutationRejected("python3 -B scripts/verify-payment-file-metadata.py runner-results --full", "echo omitted native Payment file metadata gate");
        AssertMutationRejected("python3 -B scripts/verify-paid-invoice-wire.py runner-results --full --wire", "echo omitted actual wire provenance gate");
        AssertMutationRejected("PAID_INVOICE_WIRE_OUTPUT_DIRECTORY: ${{ github.workspace }}/runner-results/paid-invoice-wire", "PAID_INVOICE_WIRE_OUTPUT_DIRECTORY: missing-witness");
    }

    [Fact]
    public void MainManualAcceptance_UsesUnfilteredFullValidationWithoutReleaseAuthority()
    {
        var source = File.ReadAllText(FindRepositoryFile(".github", "workflows", "ci-main.yml"));
        var yaml = new YamlStream();
        yaml.Load(new StringReader(source));
        var root = Assert.IsType<YamlMappingNode>(Assert.Single(yaml.Documents).RootNode);
        var triggers = Assert.IsType<YamlMappingNode>(ReadNode(root, "on"));
        Assert.Equal(new[] { "push", "workflow_dispatch" }, triggers.Children.Keys
            .Select(key => Assert.IsType<YamlScalarNode>(key).Value).OrderBy(value => value).ToArray());
        Assert.IsType<YamlScalarNode>(ReadNode(triggers, "workflow_dispatch"));
        var push = Assert.IsType<YamlMappingNode>(ReadNode(triggers, "push"));
        Assert.Single(push.Children);
        Assert.Equal("main", Assert.IsType<YamlScalarNode>(Assert.Single(
            Assert.IsType<YamlSequenceNode>(ReadNode(push, "branches")).Children)).Value);
        var permissions = Assert.IsType<YamlMappingNode>(ReadNode(root, "permissions"));
        Assert.Single(permissions.Children);
        Assert.Equal("read", ReadScalar(permissions, "contents"));
        var jobs = Assert.IsType<YamlMappingNode>(ReadNode(root, "jobs"));
        Assert.Single(jobs.Children);
        var validate = Assert.IsType<YamlMappingNode>(ReadNode(jobs, "validate"));
        Assert.Single(validate.Children);
        Assert.Equal("./.github/workflows/_build-and-test.yml", ReadScalar(validate, "uses"));
        Assert.DoesNotContain("continue-on-error", source, StringComparison.Ordinal);
        Assert.DoesNotContain("VSTestTestCaseFilter", Workflow, StringComparison.Ordinal);
        WorkflowContractValidator.Validate(Workflow);
    }

    [Fact]
    public void HistoricalJoinedDiagnostic_IsManualAndKeepsStrictReproduction()
    {
        var source = File.ReadAllText(FindRepositoryFile(".github", "workflows", "joined-public-validation.yml"));
        var yaml = new YamlStream();
        yaml.Load(new StringReader(source));
        var root = Assert.IsType<YamlMappingNode>(Assert.Single(yaml.Documents).RootNode);
        Assert.Equal("Archived public joined authorization diagnostic", ReadScalar(root, "name"));
        var triggers = Assert.IsType<YamlMappingNode>(ReadNode(root, "on"));
        Assert.Equal("workflow_dispatch", Assert.IsType<YamlScalarNode>(Assert.Single(triggers.Children).Key).Value);
        Assert.DoesNotContain("continue-on-error", source, StringComparison.Ordinal);
        Assert.Contains("python3 scripts/verify-joined-public-results.py joined-results", source, StringComparison.Ordinal);
        Assert.Contains("ref: e0438c159583a946ad66836023005755e651dff0", source, StringComparison.Ordinal);
        Assert.Contains("ref: 36c4babc80b11541a7e14fe7513683afc02a887d", source, StringComparison.Ordinal);
    }

    [Fact]
    public void CurrentAtomicAcceptance_CoversProductionChangesAndMainPushWithProducerGuard()
    {
        var source = File.ReadAllText(FindRepositoryFile(".github", "workflows", "atomic-protocol-validation.yml"));
        var yaml = new YamlStream();
        yaml.Load(new StringReader(source));
        var root = Assert.IsType<YamlMappingNode>(Assert.Single(yaml.Documents).RootNode);
        var triggers = Assert.IsType<YamlMappingNode>(ReadNode(root, "on"));
        var push = Assert.IsType<YamlMappingNode>(ReadNode(triggers, "push"));
        Assert.Equal("main", Assert.IsType<YamlScalarNode>(Assert.Single(Assert.IsType<YamlSequenceNode>(ReadNode(push, "branches")).Children)).Value);
        var pull = Assert.IsType<YamlMappingNode>(ReadNode(triggers, "pull_request"));
        var paths = Assert.IsType<YamlSequenceNode>(ReadNode(pull, "paths")).Children.Select(node => Assert.IsType<YamlScalarNode>(node).Value).ToArray();
        foreach (var path in new[]
                 {
                     "Legacy.Maliev.AccountingService.Api/**",
                     "Legacy.Maliev.AccountingService.Application/**",
                     "Legacy.Maliev.AccountingService.Data/**",
                     "Legacy.Maliev.AccountingService.Domain/**",
                     "Legacy.Maliev.AccountingService.Tests/**",
                     ".github/workflows/**",
                 })
        {
            Assert.Contains(path, paths);
        }
        Assert.DoesNotContain("continue-on-error", source, StringComparison.Ordinal);
        Assert.Contains("python3 -B scripts/verify_atomic_producer_inputs.py .joined-public/Legacy.Maliev.AccountingService", source, StringComparison.Ordinal);
        Assert.Contains("python3 -B -m unittest discover -s scripts -p test_atomic_producer_inputs.py", source, StringComparison.Ordinal);
        Assert.Contains("python3 scripts/verify-atomic-protocol-results.py atomic-results", source, StringComparison.Ordinal);
        Assert.True(source.IndexOf("Require current Accounting production", StringComparison.Ordinal)
                    < source.IndexOf("Validate prospective protocol graph", StringComparison.Ordinal));
        Assert.Contains("ref: 3d128b6d95d915ccd38323ccd66af4575800f32e", source, StringComparison.Ordinal);
    }

    [Fact]
    public void DependabotConfiguration_ScansOnlyIndependentlyResolvableProjectDirectories()
    {
        var source = File.ReadAllText(FindRepositoryFile(".github", "dependabot.yml"));
        var yaml = new YamlStream();
        yaml.Load(new StringReader(source));

        var root = Assert.IsType<YamlMappingNode>(Assert.Single(yaml.Documents).RootNode);
        var updates = Assert.IsType<YamlSequenceNode>(ReadNode(root, "updates"));
        var nuget = updates.Children
            .Select(Assert.IsType<YamlMappingNode>)
            .Single(update => ReadScalar(update, "package-ecosystem") == "nuget");
        var directories = Assert.IsType<YamlSequenceNode>(ReadNode(nuget, "directories"));

        Assert.Equal(
            [
                "/Legacy.Maliev.AccountingService.Application",
                "/Legacy.Maliev.AccountingService.Data",
                "/Legacy.Maliev.AccountingService.Domain",
            ],
            directories.Children.Select(Assert.IsType<YamlScalarNode>).Select(node => node.Value));
        Assert.False(nuget.Children.ContainsKey(new YamlScalarNode("directory")));
        Assert.False(nuget.Children.ContainsKey(new YamlScalarNode("exclude-paths")));
    }

    [Fact]
    public void DependabotConfiguration_AllowsCoordinatedEfUpdates()
    {
        var source = File.ReadAllText(FindRepositoryFile(".github", "dependabot.yml"));

        foreach (var dependency in new[]
                 {
                     "Microsoft.EntityFrameworkCore",
                     "Microsoft.EntityFrameworkCore.Abstractions",
                     "Microsoft.EntityFrameworkCore.Design",
                     "Microsoft.EntityFrameworkCore.Relational",
                     "Npgsql.EntityFrameworkCore.PostgreSQL",
                 })
        {
            Assert.DoesNotContain($"dependency-name: {dependency}", source, StringComparison.Ordinal);
        }
    }

    [Fact]
    public void BuildAndTest_RejectsSharedActionMainWithPinnedShaComment()
    {
        AssertMutationRejected(
            "MALIEV-Co-Ltd/Legacy.Maliev.Workflows/actions/dotnet-validate@e3a6093324a24968876782153286f52db8b29fd8",
            "MALIEV-Co-Ltd/Legacy.Maliev.Workflows/actions/dotnet-validate@main # e3a6093324a24968876782153286f52db8b29fd8");
    }

    [Fact]
    public void BuildAndTest_RejectsCommentedDependencySha()
    {
        AssertMutationRejected(
            "ref: 7b3099bf67d0f17e56cfdb3dcf36541304abaac2",
            "ref: main # 7b3099bf67d0f17e56cfdb3dcf36541304abaac2");
    }

    [Fact]
    public void ApiProject_UsesOnlyLegacyServiceDefaults()
    {
        Assert.Contains("Legacy.Maliev.ServiceDefaults", ApiProject, StringComparison.Ordinal);
        Assert.DoesNotContain("Maliev.Aspire\\Maliev.Aspire.ServiceDefaults", ApiProject, StringComparison.Ordinal);
        Assert.DoesNotContain("Include=\"Maliev.Aspire.ServiceDefaults\"", ApiProject, StringComparison.Ordinal);
    }

    [Fact]
    public void EfDesignDependency_IsOwnedByDataProjectOnly()
    {
        Assert.DoesNotContain("Microsoft.EntityFrameworkCore.Design", ApiProject, StringComparison.Ordinal);
        Assert.Contains("Microsoft.EntityFrameworkCore.Design", DataProject, StringComparison.Ordinal);
    }

    [Fact]
    public void BuildAndTest_RejectsJobPermissionEscalation()
    {
        AssertMutationRejected(
            "  validate:\n    name: validate",
            "  validate:\n    permissions:\n      contents: write\n    name: validate");
    }

    [Fact]
    public void BuildAndTest_RejectsSecretReferenceAnywhere()
    {
        var mutated = $"{Workflow}\n# ${{{{ secrets.X }}}}\n";

        Assert.Throws<InvalidOperationException>(() => WorkflowContractValidator.Validate(mutated));
    }

    [Theory]
    [InlineData("${{secrets.X}}")]
    [InlineData("${{ secrets['X'] }}")]
    public void BuildAndTest_RejectsSecretExpressionInJobEnvironment(string expression)
    {
        AssertMutationRejected(
            "    env:\n      MalievWorkspaceRoot: ${{ github.workspace }}/.dependencies",
            $"    env:\n      MalievWorkspaceRoot: ${{{{ github.workspace }}}}/.dependencies\n      REVIEW_TOKEN: {expression}");
    }

    [Fact]
    public void BuildAndTest_RejectsWhitespaceObfuscatedRestoreCommand()
    {
        AssertMutationRejected(
            "          solution: Legacy.Maliev.AccountingService.slnx",
            "          solution: Legacy.Maliev.AccountingService.slnx\n      - run: dotnet  restore Legacy.Maliev.AccountingService.slnx");
    }

    [Fact]
    public void BuildAndTest_RejectsMissingLocalDependencyOptIn()
    {
        AssertMutationRejected(
            "          use-local-maliev-dependencies: 'true'\n",
            string.Empty);
    }

    [Fact]
    public void BuildAndTest_RejectsReservedGitHubActionsOverride()
    {
        AssertMutationRejected(
            "          use-local-maliev-dependencies: 'true'\n",
            "          use-local-maliev-dependencies: 'true'\n        env:\n          GITHUB_ACTIONS: 'false'\n");
    }

    private static void AssertMutationRejected(string original, string replacement)
    {
        Assert.Contains(original, Workflow, StringComparison.Ordinal);
        var mutated = Workflow.Replace(original, replacement, StringComparison.Ordinal);

        Assert.Throws<InvalidOperationException>(() => WorkflowContractValidator.Validate(mutated));
    }

    private static YamlNode ReadNode(YamlMappingNode mapping, string key)
    {
        return mapping.Children[new YamlScalarNode(key)];
    }

    private static string ReadScalar(YamlMappingNode mapping, string key)
    {
        return Assert.IsType<YamlScalarNode>(ReadNode(mapping, key)).Value
            ?? throw new InvalidOperationException($"Expected '{key}' to have a scalar value.");
    }

    private static string FindRepositoryFile(params string[] segments)
    {
        DirectoryInfo? directory = new(AppContext.BaseDirectory);

        while (directory is not null)
        {
            var candidate = Path.Combine([directory.FullName, .. segments]);
            if (File.Exists(candidate))
            {
                return candidate;
            }

            directory = directory.Parent;
        }

        throw new FileNotFoundException($"Could not find repository file '{Path.Combine(segments)}'.");
    }
}

internal static partial class WorkflowContractValidator
{
    private const string CheckoutAction = "actions/checkout@3d3c42e5aac5ba805825da76410c181273ba90b1";
    private const string SharedValidationAction = "MALIEV-Co-Ltd/Legacy.Maliev.Workflows/actions/dotnet-validate@e3a6093324a24968876782153286f52db8b29fd8";

    public static void Validate(string workflow)
    {
        if (SecretExpression().IsMatch(workflow))
        {
            throw new InvalidOperationException("Workflow must not reference secrets.");
        }

        var yaml = new YamlStream();
        try
        {
            yaml.Load(new StringReader(workflow));
        }
        catch (Exception exception)
        {
            throw new InvalidOperationException("Workflow must be valid YAML.", exception);
        }

        if (yaml.Documents.Count != 1 || yaml.Documents[0].RootNode is not YamlMappingNode root)
        {
            throw new InvalidOperationException("Workflow must contain exactly one mapping document.");
        }

        var workflowPermissions = RequireExactReadOnlyPermissions(RequireMapping(root, "permissions"), "workflow");
        var jobs = RequireMapping(root, "jobs");
        if (jobs.Children.Count != 1)
        {
            throw new InvalidOperationException("Workflow must define only the validate job.");
        }

        var validateJob = RequireMapping(jobs, "validate");
        var jobPermissionsNode = GetOptional(validateJob, "permissions");
        var effectiveJobPermissions = jobPermissionsNode is null
            ? workflowPermissions
            : RequireExactReadOnlyPermissions(RequireMapping(jobPermissionsNode, "jobs.validate.permissions"), "validate job");
        if (!effectiveJobPermissions.SequenceEqual(workflowPermissions, StringComparer.Ordinal))
        {
            throw new InvalidOperationException("Validate job permissions must not differ from workflow permissions.");
        }

        RequireScalarValue(validateJob, "name", "validate");
        RejectDuplicatedValidationActionsAndCommands(jobs);

        var steps = RequireSequence(validateJob, "steps");
        if (steps.Children.Count != 10)
        {
            throw new InvalidOperationException("Validate job must contain four validation and six exact evidence steps.");
        }

        var environment = RequireMapping(validateJob, "env");
        if (environment.Children.Count != 5)
        {
            throw new InvalidOperationException("Validate environment must contain only dependency root and evidence properties.");
        }

        RequireScalarValue(environment, "MalievWorkspaceRoot", "${{ github.workspace }}/.dependencies");
        RequireScalarValue(environment, "VSTestCollect", "XPlat Code Coverage");
        RequireScalarValue(environment, "VSTestLogger", "trx");
        RequireScalarValue(environment, "VSTestResultsDirectory", "${{ github.workspace }}/runner-results");
        RequireScalarValue(environment, "PAID_INVOICE_WIRE_OUTPUT_DIRECTORY", "${{ github.workspace }}/runner-results/paid-invoice-wire");

        var gate = RequireMapping(steps.Children[4], "coverage gate");
        if (gate.Children.Count != 2)
        {
            throw new InvalidOperationException("Coverage gate must contain only name and run.");
        }

        RequireScalarValue(gate, "name", "Gate owned production coverage");
        RequireScalarValue(gate, "run", "python3 scripts/verify-runner-coverage.py runner-results");
        var employeeGate = RequireMapping(steps.Children[5], "employee execution gate");
        if (employeeGate.Children.Count != 2)
        {
            throw new InvalidOperationException("Employee gate must contain only name and run.");
        }
        RequireScalarValue(employeeGate, "name", "Verify full 1671 executions and employee inventory");
        RequireScalarValue(employeeGate, "run", "python3 -B scripts/verify-employee-completion.py runner-results --full");
        var fileGate = RequireMapping(steps.Children[6], "file metadata execution gate");
        if (fileGate.Children.Count != 2)
        {
            throw new InvalidOperationException("File metadata gate must contain only name and run.");
        }
        RequireScalarValue(fileGate, "name", "Verify full 1671 executions and file metadata inventory");
        RequireScalarValue(fileGate, "run", "python3 -B scripts/verify-file-metadata.py runner-results --full");
        var paymentFileGate = RequireMapping(steps.Children[7], "Payment file metadata execution gate");
        if (paymentFileGate.Children.Count != 2)
        {
            throw new InvalidDataException("Payment file metadata execution gate has unexpected fields.");
        }
        RequireScalarValue(paymentFileGate, "name", "Verify full 1671 executions and Payment file metadata inventory");
        RequireScalarValue(paymentFileGate, "run", "python3 -B scripts/verify-payment-file-metadata.py runner-results --full");
        var wireGate = RequireMapping(steps.Children[8], "PaidInvoice actual wire execution/provenance gate");
        if (wireGate.Children.Count != 2)
        {
            throw new InvalidDataException("PaidInvoice wire gate has unexpected fields.");
        }
        RequireScalarValue(wireGate, "name", "Verify full 1671 executions and actual PaidInvoice wire provenance");
        RequireScalarValue(wireGate, "run", "python3 -B scripts/verify-paid-invoice-wire.py runner-results --full --wire");
        var evidence = RequireMapping(steps.Children[9], "evidence upload");
        if (evidence.Children.Count != 4)
        {
            throw new InvalidOperationException("Evidence upload must contain exactly name, if, uses and with.");
        }

        RequireScalarValue(evidence, "name", "Preserve validation evidence");
        RequireScalarValue(evidence, "if", "always()");
        RequireScalarValue(evidence, "uses", "actions/upload-artifact@ea165f8d65b6e75b540449e92b4886f43607fa02");
        var evidenceInputs = RequireMapping(evidence, "with");
        if (evidenceInputs.Children.Count != 4)
        {
            throw new InvalidOperationException("Evidence upload must have exactly four bounded inputs.");
        }

        RequireScalarValue(evidenceInputs, "name", "accounting-validation-${{ github.sha }}");
        RequireScalarValue(evidenceInputs, "path", "runner-results");
        RequireScalarValue(evidenceInputs, "if-no-files-found", "warn");
        RequireScalarValue(evidenceInputs, "retention-days", "7");

        ValidateStep(
            steps.Children[0],
            CheckoutAction,
            new Dictionary<string, string>(StringComparer.Ordinal)
            {
                ["persist-credentials"] = "false",
            });
        ValidateStep(
            steps.Children[1],
            CheckoutAction,
            new Dictionary<string, string>(StringComparer.Ordinal)
            {
                ["repository"] = "MALIEV-Co-Ltd/Legacy.Maliev.ServiceDefaults",
                ["ref"] = "7b3099bf67d0f17e56cfdb3dcf36541304abaac2",
                ["path"] = ".dependencies/Legacy.Maliev.ServiceDefaults",
                ["persist-credentials"] = "false",
            });
        ValidateStep(
            steps.Children[2],
            CheckoutAction,
            new Dictionary<string, string>(StringComparer.Ordinal)
            {
                ["repository"] = "MALIEV-Co-Ltd/Legacy.Maliev.CompatibilityContracts",
                ["ref"] = "78e48ffc4ee000df0510cba5e7c7a3c4c4d539d7",
                ["path"] = ".dependencies/Legacy.Maliev.CompatibilityContracts",
                ["persist-credentials"] = "false",
            });
        ValidateStep(
            steps.Children[3],
            SharedValidationAction,
            new Dictionary<string, string>(StringComparer.Ordinal)
            {
                ["solution"] = "Legacy.Maliev.AccountingService.slnx",
                ["use-local-maliev-dependencies"] = "true",
            });
    }

    private static IReadOnlyList<string> RequireExactReadOnlyPermissions(YamlMappingNode permissions, string scope)
    {
        if (permissions.Children.Count != 1)
        {
            throw new InvalidOperationException($"{scope} permissions must contain only contents: read.");
        }

        RequireScalarValue(permissions, "contents", "read");
        return ["contents:read"];
    }

    private static void ValidateStep(
        YamlNode node,
        string expectedAction,
        IReadOnlyDictionary<string, string> expectedInputs)
    {
        var step = RequireMapping(node, "workflow step");
        var allowedKeys = new HashSet<string>(["name", "uses", "with"], StringComparer.Ordinal);

        var actualKeys = step.Children.Keys.Select(RequireScalar).ToHashSet(StringComparer.Ordinal);
        if (!actualKeys.SetEquals(allowedKeys))
        {
            throw new InvalidOperationException("Each workflow step must contain exactly name, uses, and with.");
        }

        var name = RequireScalar(GetRequired(step, "name"));
        if (string.IsNullOrWhiteSpace(name))
        {
            throw new InvalidOperationException("Workflow step name must not be empty.");
        }

        RequireScalarValue(step, "uses", expectedAction);
        var inputs = RequireMapping(step, "with");
        if (inputs.Children.Count != expectedInputs.Count)
        {
            throw new InvalidOperationException($"Action {expectedAction} has an unexpected input count.");
        }

        foreach (var expectedInput in expectedInputs)
        {
            RequireScalarValue(inputs, expectedInput.Key, expectedInput.Value);
        }

        var environment = GetOptional(step, "env");
        if (environment is not null)
        {
            throw new InvalidOperationException("Workflow action steps must not override reserved environment variables.");
        }

        if (expectedInputs.ContainsKey("use-local-maliev-dependencies"))
        {
            var useLocalDependencies = GetRequired(inputs, "use-local-maliev-dependencies") as YamlScalarNode;
            if (useLocalDependencies?.Style != ScalarStyle.SingleQuoted)
            {
                throw new InvalidOperationException("use-local-maliev-dependencies must use the single-quoted string value 'true'.");
            }
        }
    }

    private static void RejectDuplicatedValidationActionsAndCommands(YamlMappingNode jobs)
    {
        foreach (var jobNode in jobs.Children.Values.OfType<YamlMappingNode>())
        {
            var stepsNode = GetOptional(jobNode, "steps");
            if (stepsNode is not YamlSequenceNode steps)
            {
                continue;
            }

            foreach (var stepNode in steps.Children.OfType<YamlMappingNode>())
            {
                if (GetOptional(stepNode, "uses") is YamlScalarNode usesNode)
                {
                    var action = usesNode.Value ?? string.Empty;
                    if (action.StartsWith("actions/setup-dotnet@", StringComparison.OrdinalIgnoreCase)
                        || action.StartsWith("actions/cache@", StringComparison.OrdinalIgnoreCase))
                    {
                        throw new InvalidOperationException($"Caller duplicates shared action {action}.");
                    }
                }

                if (GetOptional(stepNode, "run") is YamlScalarNode runNode)
                {
                    RejectDuplicatedDotNetCommand(runNode.Value ?? string.Empty);
                }
            }
        }
    }

    private static void RejectDuplicatedDotNetCommand(string command)
    {
        var tokens = command
            .Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .Select(token => token.Trim('"', '\'', ';', '&', '|').ToLowerInvariant())
            .Where(token => token.Length > 0)
            .ToArray();

        for (var index = 0; index < tokens.Length - 1; index++)
        {
            if (!string.Equals(tokens[index], "dotnet", StringComparison.Ordinal))
            {
                continue;
            }

            var verb = tokens[index + 1];
            if (verb is "restore" or "build" or "test" or "format" or "list"
                || tokens[(index + 1)..].Any(token => token is "audit" or "--vulnerable"))
            {
                throw new InvalidOperationException($"Caller duplicates shared dotnet validation command: {verb}.");
            }
        }
    }

    private static YamlMappingNode RequireMapping(YamlMappingNode parent, string key) =>
        RequireMapping(GetRequired(parent, key), key);

    private static YamlMappingNode RequireMapping(YamlNode node, string description)
    {
        return node as YamlMappingNode
            ?? throw new InvalidOperationException($"{description} must be a mapping.");
    }

    private static YamlSequenceNode RequireSequence(YamlMappingNode parent, string key)
    {
        return GetRequired(parent, key) as YamlSequenceNode
            ?? throw new InvalidOperationException($"{key} must be a sequence.");
    }

    private static void RequireScalarValue(YamlMappingNode parent, string key, string expected)
    {
        var actual = RequireScalar(GetRequired(parent, key));
        if (!string.Equals(actual, expected, StringComparison.Ordinal))
        {
            throw new InvalidOperationException($"{key} must equal '{expected}', but was '{actual}'.");
        }
    }

    private static string RequireScalar(YamlNode node)
    {
        return (node as YamlScalarNode)?.Value
            ?? throw new InvalidOperationException("Expected a scalar YAML value.");
    }

    private static YamlNode GetRequired(YamlMappingNode parent, string key)
    {
        return GetOptional(parent, key)
            ?? throw new InvalidOperationException($"Missing required YAML key '{key}'.");
    }

    private static YamlNode? GetOptional(YamlMappingNode parent, string key)
    {
        foreach (var child in parent.Children)
        {
            if (child.Key is YamlScalarNode scalar && string.Equals(scalar.Value, key, StringComparison.Ordinal))
            {
                return child.Value;
            }
        }

        return null;
    }

    [GeneratedRegex(@"\$\{\{\s*secrets\s*(?:\.|\[)", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant)]
    private static partial Regex SecretExpression();
}
