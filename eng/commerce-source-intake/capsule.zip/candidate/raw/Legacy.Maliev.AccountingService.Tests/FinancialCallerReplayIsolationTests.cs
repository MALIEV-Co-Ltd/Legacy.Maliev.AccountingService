using System.Net;
using System.Net.Http.Json;
using System.Security.Claims;
using System.Text.Json.Nodes;
using Legacy.Maliev.AccountingService.Api.Authorization;
using Legacy.Maliev.AccountingService.Api.Controllers.Payment;
using Legacy.Maliev.AccountingService.Application.Interfaces;
using Legacy.Maliev.AccountingService.Domain.Payment;
using Legacy.Maliev.AccountingService.Tests.Fixtures;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Moq;

namespace Legacy.Maliev.AccountingService.Tests;

public sealed class FinancialCallerReplayIsolationTests(AccountingBoundaryHttpFixture fixture)
    : IClassFixture<AccountingBoundaryHttpFixture>
{
    [Theory]
    [InlineData("Accounts")]
    [InlineData("Directions")]
    [InlineData("Methods")]
    [InlineData("Types")]
    [InlineData("Payments")]
    [InlineData("Invoices")]
    [InlineData("Receipts")]
    public async Task SameKeySeparatesSignedCallersAndRetainsEachCallersOriginalReplay(string resource)
    {
        await fixture.ResetAsync();
        using var first = await ClientAsync();
        using var second = await ClientAsync();
        var key = Guid.NewGuid().ToString("D");
        first.DefaultRequestHeaders.Add("Idempotency-Key", key);
        second.DefaultRequestHeaders.Add("Idempotency-Key", key);
        var before = await fixture.ReceiptSnapshotAsync();
        var redisBefore = await fixture.ReceiptRedisSnapshotAsync();
        var left = await PostAsync(first, resource, "caller-one");
        var right = await PostAsync(second, resource, "caller-two");
        Assert.NotEqual(left["Id"]!.GetValue<int>(), right["Id"]!.GetValue<int>());
        Assert.Equal("caller-one", left[Field(resource)]!.GetValue<string>());
        Assert.Equal("caller-two", right[Field(resource)]!.GetValue<string>());
        Assert.Equal(left.ToJsonString(), (await PostAsync(first, resource, "replacement-one")).ToJsonString());
        Assert.Equal(right.ToJsonString(), (await PostAsync(second, resource, "replacement-two")).ToJsonString());
        var expected = SourceMutationProof.RedisKeys(first, "unused", Scope(resource))
            .Where(pair => pair.Key != "unused").ToDictionary(pair => pair.Key, pair => pair.Value);
        foreach (var pair in SourceMutationProof.RedisKeys(second, "unused", Scope(resource)).Where(pair => pair.Key != "unused"))
            expected.Add(pair.Key, pair.Value);
        Assert.Equal(2, expected.Count);
        await fixture.AssertReceiptRedisChangesAsync(redisBefore, expected, false);
        var after = await fixture.ReceiptSnapshotAsync();
        if (resource != "Invoices") Assert.Equal(before.Invoice, after.Invoice);
        if (resource != "Receipts") Assert.Equal(before.Receipt, after.Receipt);
        Assert.Equal(before.Journal, after.Journal);
        using var leftRead = await first.GetAsync($"{Route(resource)}/{left["Id"]!.GetValue<int>()}");
        using var rightRead = await second.GetAsync($"{Route(resource)}/{right["Id"]!.GetValue<int>()}");
        await fixture.AssertStatusAsync(leftRead, HttpStatusCode.OK);
        await fixture.AssertStatusAsync(rightRead, HttpStatusCode.OK);
        Assert.Equal("caller-one", (await leftRead.Content.ReadFromJsonAsync<JsonObject>())![Field(resource)]!.GetValue<string>());
        Assert.Equal("caller-two", (await rightRead.Content.ReadFromJsonAsync<JsonObject>())![Field(resource)]!.GetValue<string>());
    }

    [Theory]
    [InlineData("Accounts")]
    [InlineData("Directions")]
    [InlineData("Methods")]
    [InlineData("Types")]
    [InlineData("Payments")]
    [InlineData("Invoices")]
    [InlineData("Receipts")]
    public async Task LegacyUnboundMemoNeverBecomesAnAuthenticatedCallersResponse(string resource)
    {
        await fixture.ResetAsync();
        using var client = await ClientAsync();
        var key = Guid.NewGuid().ToString("D");
        client.DefaultRequestHeaders.Add("Idempotency-Key", key);
        var poison = Body(resource, "legacy-unbound");
        poison["Id"] = 987654;
        await fixture.SeedLegacyCreateMemoAsync(Scope(resource), key, poison);
        var before = await fixture.ReceiptRedisSnapshotAsync();
        var response = await PostAsync(client, resource, "new-bound");
        Assert.NotEqual(987654, response["Id"]!.GetValue<int>());
        Assert.Equal("new-bound", response[Field(resource)]!.GetValue<string>());
        var expected = SourceMutationProof.RedisKeys(client, "unused", Scope(resource))
            .Where(pair => pair.Key != "unused").ToDictionary(pair => pair.Key, pair => pair.Value);
        await fixture.AssertReceiptRedisChangesAsync(before, expected, false);
    }

    [Theory]
    [InlineData(false)]
    [InlineData(true)]
    public async Task KeyedCreateWithoutOneSignedIdentityRefusesBeforeStoreOrRepository(bool duplicateSubject)
    {
        var service = new Mock<IAccountingService>(MockBehavior.Strict);
        var memo = new Mock<IIdempotencyStore>(MockBehavior.Strict);
        var claims = new List<Claim> { new("iss", "https://synthetic.invalid") };
        if (duplicateSubject)
        {
            claims.Add(new("sub", "caller-one"));
            claims.Add(new("sub", "caller-two"));
        }
        var controller = new AccountsController(service.Object, memo.Object)
        {
            ControllerContext = new ControllerContext
            {
                HttpContext = new DefaultHttpContext { User = new ClaimsPrincipal(new ClaimsIdentity(claims, "controlled-proof")) }
            }
        };
        var result = await controller.CreateAccountAsync(new Account(), "same-key", CancellationToken.None);
        Assert.IsType<ForbidResult>(result.Result);
        service.VerifyNoOtherCalls();
        memo.VerifyNoOtherCalls();
    }

    private Task<HttpClient> ClientAsync() => fixture.ReceiptClientAsync([AccountingPermissions.Create, AccountingPermissions.Read]);
    private static string Scope(string resource) => resource.ToLowerInvariant();
    private static string Route(string resource) => resource is "Payments" or "Invoices" or "Receipts"
        ? $"/{resource.ToLowerInvariant()}" : $"/payments/{resource}";
    private static string Field(string resource) => resource switch
    {
        "Accounts" => "Bank",
        "Invoices" => "Number",
        "Receipts" => "Comment",
        "Payments" => "Description",
        _ => "Name"
    };
    private static JsonObject Body(string resource, string value) => resource switch
    {
        "Accounts" => new JsonObject { ["Bank"] = value, ["AccountNumber"] = "SYNTHETIC", ["Branch"] = "test", ["Swift"] = "test" },
        "Invoices" => new JsonObject { ["Number"] = value, ["Currency"] = "THB" },
        "Receipts" => new JsonObject { ["Comment"] = value, ["Currency"] = "THB" },
        "Payments" => new JsonObject { ["Description"] = value },
        _ => new JsonObject { ["Name"] = value, ["Description"] = "synthetic" }
    };

    private async Task<JsonObject> PostAsync(HttpClient client, string resource, string value)
    {
        using var response = await client.PostAsJsonAsync(Route(resource), Body(resource, value));
        await fixture.AssertStatusAsync(response, HttpStatusCode.Created);
        return (await response.Content.ReadFromJsonAsync<JsonObject>())!;
    }
}
