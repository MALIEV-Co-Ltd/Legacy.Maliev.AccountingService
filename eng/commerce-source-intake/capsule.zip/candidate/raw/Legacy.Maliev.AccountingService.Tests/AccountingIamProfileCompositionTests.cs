using System.Net;
using System.Reflection;
using Legacy.Maliev.AccountingService.Api.Controllers.Invoice;
using Maliev.Aspire.ServiceDefaults;
using Maliev.Aspire.ServiceDefaults.LegacyAuth;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Moq;

namespace Legacy.Maliev.AccountingService.Tests;

public sealed class AccountingIamProfileCompositionTests
{
    [Fact]
    public void RegisteredIamClientUsesSeparateIamHandlerAndGeneralClientRetainsLegacyHandler()
    {
        var builder = Compose();
        builder.Services.AddHttpClient("FinancialLegacyProof").AddLegacyServiceAuthentication();
        using var provider = builder.Services.BuildServiceProvider();
        var factory = provider.GetRequiredService<IHttpMessageHandlerFactory>();
        var iam = Chain(factory.CreateHandler("IAMService"));
        var financial = Chain(factory.CreateHandler("FinancialLegacyProof"));
        Assert.Single(iam, type => type == typeof(LegacyIamServiceAuthenticationHandler));
        Assert.DoesNotContain(typeof(LegacyServiceAuthenticationHandler), iam);
        Assert.Single(financial, type => type == typeof(LegacyServiceAuthenticationHandler));
        Assert.DoesNotContain(typeof(LegacyIamServiceAuthenticationHandler), financial);
    }

    [Fact]
    public async Task MissingIamProfileStopsRegisteredTransportWithoutCallingLegacyProviderOrNetwork()
    {
        var builder = Compose();
        var missing = new Mock<ILegacyIamServiceAccessTokenProvider>(MockBehavior.Strict);
        missing.Setup(value => value.GetAccessTokenAsync(It.IsAny<CancellationToken>()))
            .Returns(new ValueTask<string?>((string?)null));
        var legacy = new Mock<ILegacyServiceAccessTokenProvider>(MockBehavior.Strict);
        builder.Services.AddSingleton(missing.Object);
        builder.Services.AddSingleton(legacy.Object);
        var network = new CountingNetwork();
        builder.Services.AddHttpClient("IAMService").ConfigurePrimaryHttpMessageHandler(() => network);
        using var provider = builder.Services.BuildServiceProvider();
        using var client = provider.GetRequiredService<IHttpClientFactory>().CreateClient("IAMService");
        using var request = new HttpRequestMessage(HttpMethod.Post, "/iam/v1/auth/check-permission");
        var failure = await Assert.ThrowsAsync<HttpRequestException>(() => client.SendAsync(request));
        Assert.Equal(HttpStatusCode.ServiceUnavailable, failure.StatusCode);
        Assert.Equal(0, network.Calls);
        missing.Verify(value => value.GetAccessTokenAsync(It.IsAny<CancellationToken>()), Times.Once);
        legacy.VerifyNoOtherCalls();
    }

    private static HostApplicationBuilder Compose()
    {
        var builder = Host.CreateApplicationBuilder(new HostApplicationBuilderSettings { EnvironmentName = "Testing" });
        builder.Configuration.AddInMemoryCollection(new Dictionary<string, string?>
        {
            ["Services:IAMService:BaseUrl"] = "https://iam-profile-proof.invalid",
            ["Services:Auth:BaseUrl"] = "https://auth-profile-proof.invalid"
        });
        builder.AddServiceDefaults();
        builder.AddLegacyAuthServiceTokenExchange();
        var composition = typeof(InvoiceFinancialOwnershipController).Assembly.GetType(
            "Legacy.Maliev.AccountingService.Api.Authorization.AccountingIamComposition", throwOnError: true)!;
        var actualRegistration = composition.GetMethod("AddAccountingIamClient", BindingFlags.Static | BindingFlags.NonPublic)!;
        actualRegistration.Invoke(null, [builder]);
        return builder;
    }

    private static IReadOnlyList<Type> Chain(HttpMessageHandler handler)
    {
        var types = new List<Type>();
        while (true)
        {
            types.Add(handler.GetType());
            if (handler is not DelegatingHandler { InnerHandler: { } inner }) return types;
            handler = inner;
        }
    }

    private sealed class CountingNetwork : HttpMessageHandler
    {
        public int Calls { get; private set; }
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            Calls++;
            throw new InvalidOperationException("No IAM proof request may reach a physical network.");
        }
    }
}
