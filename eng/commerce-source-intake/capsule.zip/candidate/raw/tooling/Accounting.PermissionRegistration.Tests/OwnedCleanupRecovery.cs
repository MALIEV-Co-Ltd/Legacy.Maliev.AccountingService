namespace Accounting.PermissionRegistration.Tests;

// Physical cleanup recovery is separate from (and never changes) the original qualification task.
internal sealed class OwnedCleanupRecovery(
    Task originalCleanup,
    Func<bool> contextsClosed,
    Func<CancellationToken, Task> verifyExactOwnerAndIdle,
    Func<CancellationToken, Task> removeExactBackend,
    Func<CancellationToken, Task<bool>> verifyBackendAbsent)
{
    private readonly object gate = new();
    private Task? recovery;
    private Task? backendDisposal;

    internal Task RecoverAsync(TimeSpan timeout, CancellationToken cancellation = default)
    {
        lock (gate)
        {
            // Retry a failed physical recovery; never run removal attempts concurrently.
            if (recovery is null || recovery.IsFaulted || recovery.IsCanceled)
                recovery = RecoverCoreAsync(timeout, cancellation);
            return recovery;
        }
    }

    private async Task RecoverCoreAsync(TimeSpan timeout, CancellationToken cancellation)
    {
        using var lifetime = CancellationTokenSource.CreateLinkedTokenSource(cancellation);
        lifetime.CancelAfter(timeout);
        try { await originalCleanup.WaitAsync(lifetime.Token); }
        catch (Exception) when (originalCleanup.IsCompleted)
        {
            // Settlement is not qualification success. A separate physical-close/idle gate remains mandatory.
        }
        lifetime.Token.ThrowIfCancellationRequested();
        if (!originalCleanup.IsCompleted || !contextsClosed())
            throw new InvalidOperationException("Original context cleanup has not established physical closure.");
        await verifyExactOwnerAndIdle(lifetime.Token);
        // Retain the original backend disposal task too. A retry checks its completion/physical result,
        // rather than starting a second concurrent or repeated container disposal.
        backendDisposal ??= removeExactBackend(lifetime.Token);
        try { await backendDisposal.WaitAsync(lifetime.Token); }
        catch (Exception) when (backendDisposal.IsCompleted)
        {
            // An acknowledgement failure is not absence; the mandatory physical check decides cleanup only.
        }
        lifetime.Token.ThrowIfCancellationRequested();
        if (!await verifyBackendAbsent(lifetime.Token))
            throw new InvalidOperationException("Owned backend physical absence is unverified.");
    }
}
