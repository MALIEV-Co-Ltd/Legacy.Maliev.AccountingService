using System.IdentityModel.Tokens.Jwt;
using System.Security.Cryptography;
using System.Text.Json;
using Legacy.Maliev.AuthService.Infrastructure;
using Maliev.IAMService.Application.DTOs.Requests;
using Maliev.IAMService.Application.Interfaces;
using Maliev.IAMService.Application.Services;
using Maliev.IAMService.Domain.Entities;
using Maliev.IAMService.Infrastructure.Persistence;
using Maliev.IAMService.Infrastructure.Repositories;
using MassTransit;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Moq;
using Npgsql;
using Testcontainers.PostgreSql;
using Docker.DotNet;
using System.Runtime.ExceptionServices;

[assembly: CollectionBehavior(DisableTestParallelization = true)]

namespace Accounting.PermissionRegistration.Tests;

// Real source issuer, persisted IAM catalogue/principal/role/binding and actual resolver.
// This is the ordinary service-account email enrollment path, not managed-workload or HTTP join acceptance.
public sealed class OrdinaryFinancialPrincipalTests : IClassFixture<OrdinaryFinancialPrincipalFixture>
{
    private const string Permission = "legacy.accounting-financial-ownership.read";
    private readonly OrdinaryFinancialPrincipalFixture fixture;
    public OrdinaryFinancialPrincipalTests(OrdinaryFinancialPrincipalFixture fixture) => this.fixture = fixture;

    [Theory]
    [InlineData("legacy-auth")]
    [InlineData("legacy-quotation")]
    public async Task OrdinaryEmailEnrollmentResolvesActualOpaqueJwtToPersistedGuidAndGlobalRead(string client)
    {
        await using var boundary = fixture.Open();
        var account = await boundary.EnrollAsync(client);
        await boundary.GrantAsync(account, null);
        var subject = fixture.IssueAndValidateSubject(client, Permission);
        Assert.Equal(account.PrincipalId, await boundary.Principals.ResolvePrincipalIdAsync(subject));
        var response = await boundary.CheckAsync(subject);
        Assert.True(response.Allowed);
        Assert.Equal(account.PrincipalId, response.PrincipalId);
        Assert.Equal("global", response.ResourcePath);
        Assert.False(response.FromCache);
        Assert.Null(account.WorkloadId);
        Assert.True(await boundary.Database.Principals.AsNoTracking().AnyAsync(row => row.PrincipalId == account.PrincipalId));
    }

    [Theory]
    [InlineData("legacy-auth")]
    [InlineData("legacy-quotation")]
    public async Task TokenPermissionWithoutPersistedGrantIsDenied(string client)
    {
        await using var boundary = fixture.Open();
        await boundary.EnrollAsync(client);
        Assert.False((await boundary.CheckAsync(fixture.IssueAndValidateSubject(client, Permission))).Allowed);
    }

    [Theory]
    [InlineData("legacy-auth")]
    [InlineData("legacy-quotation")]
    public async Task NonmatchingScopedBindingDoesNotAuthorizeIntentionalGlobalOperationRead(string client)
    {
        await using var boundary = fixture.Open();
        var account = await boundary.EnrollAsync(client);
        await boundary.GrantAsync(account, "operations/unrelated-fixture-operation");
        Assert.False((await boundary.CheckAsync(fixture.IssueAndValidateSubject(client, Permission))).Allowed);
    }

    [Theory]
    [InlineData("legacy-auth")]
    [InlineData("legacy-quotation")]
    public async Task OrdinaryRevocationRemovesRealBindingAndNextBypassCacheReadIsDenied(string client)
    {
        await using var boundary = fixture.Open();
        var account = await boundary.EnrollAsync(client);
        var binding = await boundary.GrantAsync(account, null);
        var subject = fixture.IssueAndValidateSubject(client, Permission);
        Assert.True((await boundary.CheckAsync(subject)).Allowed);
        await boundary.Bindings.RevokeRoleAsync(account.PrincipalId, binding.BindingId, account.PrincipalId);
        Assert.False(await boundary.Database.PrincipalRoleBindings.AsNoTracking().AnyAsync(row => row.BindingId == binding.BindingId));
        Assert.False((await boundary.CheckAsync(subject)).Allowed);
    }

    [Theory]
    [InlineData("legacy-auth")]
    [InlineData("legacy-quotation")]
    public async Task InactivePersistedOrdinaryPrincipalCannotUseItsExistingGlobalGrant(string client)
    {
        await using var boundary = fixture.Open();
        var account = await boundary.EnrollAsync(client);
        await boundary.GrantAsync(account, null);
        account.IsActive = false;
        await boundary.Principals.UpdateAsync(account);
        Assert.False((await boundary.CheckAsync(fixture.IssueAndValidateSubject(client, Permission))).Allowed);
    }

    [Theory]
    [InlineData("legacy-auth")]
    [InlineData("legacy-quotation")]
    public async Task UnenrolledOpaqueServiceSubjectFailsClosedWithoutAliasOrInventedGuid(string client)
    {
        await using var boundary = fixture.Open();
        var subject = fixture.IssueAndValidateSubject(client, Permission);
        await Assert.ThrowsAsync<InvalidOperationException>(() => boundary.Principals.ResolvePrincipalIdAsync(subject));
        var response = await boundary.CheckAsync(subject);
        Assert.False(response.Allowed);
        Assert.Equal(Guid.Empty, response.PrincipalId);
    }
}

public sealed class OrdinaryFinancialPrincipalFixture : IAsyncLifetime
{
    private const string Issuer = "https://ordinary-financial-principal.invalid";
    private const string Audience = "ordinary-financial-principal";
    private readonly PostgreSqlContainer postgres = OwnedFinancialPrincipalTestContainers.Postgres("postgres:18-alpine").Build();
    private readonly RSA key = RSA.Create(2048);
    private RsaAccessTokenIssuer? issuer;
    private string? connection;
    private readonly List<OrdinaryFinancialBoundary> boundaries = [];
    private readonly object disposalGate = new();
    private Task? disposal;
    private Task? qualification;
    private Task? backendDisposal;
    private OwnedCleanupRecovery? recovery;
    private string? originalBackendId;
    private string? originalImageId;
    private string? originalCreated;

    public Task InitializeAsync() => OwnedFinancialPrincipalTestContainers.SetupAsync(async cancellation =>
    {
        await postgres.StartAsync(cancellation);
        originalBackendId = postgres.Id;
        using (var docker = Docker())
        {
            var inspect = await docker.Containers.InspectContainerAsync(originalBackendId, cancellation);
            originalImageId = inspect.Image;
            originalCreated = inspect.Created.ToString();
        }
        Console.WriteLine($"Owned financial principal PostgreSQL started: {postgres.Id}; parent run: {OwnedFinancialPrincipalTestContainers.ParentRun}");
        var actual = new NpgsqlConnectionStringBuilder(postgres.GetConnectionString()) { Pooling = false };
        if (actual.Host is not ("localhost" or "127.0.0.1") || actual.Port != postgres.GetMappedPublicPort(5432)
            || string.IsNullOrEmpty(postgres.Id)) throw new InvalidOperationException("Fixture requires its owned loopback PostgreSQL.");
        connection = actual.ConnectionString;
        await using var database = Context();
        await database.Database.MigrateAsync(cancellation);
        issuer = new RsaAccessTokenIssuer(Options.Create(new JwtOptions
        {
            Issuer = Issuer, Audience = Audience, PrivateKeyPem = key.ExportPkcs8PrivateKeyPem(), KeyId = "owned-fixture"
        }));
    }, DisposeAsync);

    private IAMDbContext Context() => new(new DbContextOptionsBuilder<IAMDbContext>()
        .UseNpgsql(connection ?? throw new InvalidOperationException("Fixture not initialized."), options => options.CommandTimeout(30))
        .Options);

    public OrdinaryFinancialBoundary Open()
    {
        var context = Context();
        try
        {
            var boundary = new OrdinaryFinancialBoundary(context);
            boundaries.Add(boundary);
            return boundary;
        }
        catch { context.Dispose(); throw; }
    }

    public string IssueAndValidateSubject(string client, string permission)
    {
        var issued = (issuer ?? throw new InvalidOperationException("Issuer not initialized."))
            .IssueService(client, [permission], DateTimeOffset.UtcNow);
        var handler = new JwtSecurityTokenHandler { MapInboundClaims = false };
        var principal = handler.ValidateToken(issued.Value, new TokenValidationParameters
        {
            ValidateIssuer = true, ValidIssuer = Issuer, ValidateAudience = true, ValidAudience = Audience,
            ValidateIssuerSigningKey = true, IssuerSigningKey = new RsaSecurityKey(key), ValidateLifetime = true,
            ValidAlgorithms = [SecurityAlgorithms.RsaSha256], ClockSkew = TimeSpan.Zero
        }, out _);
        Assert.Empty(principal.FindAll("user_id"));
        Assert.Empty(principal.FindAll(System.Security.Claims.ClaimTypes.NameIdentifier));
        Assert.Equal("service", Assert.Single(principal.FindAll("identity_kind")).Value);
        var subject = Assert.Single(principal.FindAll("sub")).Value;
        Assert.Equal("service:" + client, subject);
        return subject;
    }

    public Task DisposeAsync()
    {
        lock (disposalGate)
        {
            qualification ??= DisposeCoreAsync();
            return disposal ??= SuperviseAsync(qualification);
        }
    }

    private async Task DisposeCoreAsync()
    {
        issuer?.Dispose();
        key.Dispose();
        // All actual contexts must finish cleanup before backend removal; cached disposal faults remain faults.
        await OwnedFinancialPrincipalTestContainers.CleanupAsync(boundaries.Select<OrdinaryFinancialBoundary, Func<Task>>(
            boundary => () => boundary.DisposeAsync().AsTask()).ToArray());
        using var lifetime = new CancellationTokenSource(TimeSpan.FromSeconds(30));
        await VerifyExactOwnerAndIdleAsync(lifetime.Token);
        backendDisposal ??= postgres.DisposeAsync().AsTask();
        await backendDisposal.WaitAsync(lifetime.Token);
        if (!await BackendAbsentAsync(lifetime.Token)) throw new InvalidOperationException("Owned PostgreSQL absence is unverified.");
    }

    private async Task SuperviseAsync(Task originalQualification)
    {
        try { await originalQualification; }
        catch (Exception failure)
        {
            // The original outer task has now settled. Recover physical cleanup separately, then preserve FAIL.
            try { await RecoverBackendAsync(); }
            catch (Exception recoveryFailure) { throw new AggregateException(failure, recoveryFailure); }
            ExceptionDispatchInfo.Capture(failure).Throw();
        }
    }

    public Task RecoverBackendAsync(CancellationToken cancellation = default)
    {
        lock (disposalGate)
        {
            if (qualification is null || !qualification.IsCompleted)
                throw new InvalidOperationException("Physical recovery requires the original outer disposal task to settle.");
            recovery ??= new OwnedCleanupRecovery(
                Task.WhenAll(boundaries.Select(boundary => boundary.DisposeAsync().AsTask())),
                () => boundaries.All(boundary => boundary.PhysicalContextClosed),
                VerifyExactOwnerAndIdleAsync,
                _ => backendDisposal ??= postgres.DisposeAsync().AsTask(),
                BackendAbsentAsync);
            return recovery.RecoverAsync(TimeSpan.FromSeconds(120), cancellation);
        }
    }

    private static DockerClient Docker() => new DockerClientBuilder()
        .WithEndpoint(new Uri(OwnedFinancialPrincipalTestContainers.DockerEndpoint))
        .WithTimeout(TimeSpan.FromSeconds(15)).Build();

    private async Task<bool> BackendAbsentAsync(CancellationToken cancellation)
    {
        var id = originalBackendId ?? postgres.Id;
        if (string.IsNullOrEmpty(id)) return true;
        using var docker = Docker();
        try { _ = await docker.Containers.InspectContainerAsync(id, cancellation); return false; }
        catch (DockerContainerNotFoundException) { return true; }
    }

    private async Task VerifyExactOwnerAndIdleAsync(CancellationToken cancellation)
    {
        var id = originalBackendId ?? postgres.Id;
        if (string.IsNullOrEmpty(id)) return;
        using var docker = Docker();
        Docker.DotNet.Models.ContainerInspectResponse inspect;
        try { inspect = await docker.Containers.InspectContainerAsync(id, cancellation); }
        catch (DockerContainerNotFoundException) { return; }
        var labels = inspect.Config.Labels;
        bool Label(string name, string expected) => labels.TryGetValue(name, out var value) && value == expected;
        if (inspect.ID != id || inspect.Config.Image != "postgres:18-alpine"
            || !Label("maliev.codex.owner", "commerce-accounting-financial-principal-20261007")
            || !Label("maliev.codex.parent-run", OwnedFinancialPrincipalTestContainers.ParentRun)
            || !Label("maliev.codex.run", OwnedFinancialPrincipalTestContainers.Run)
            || !Label("maliev.codex.persistent-data", "false")
            || (originalImageId is not null && inspect.Image != originalImageId)
            || (originalCreated is not null && inspect.Created.ToString() != originalCreated)
            || !inspect.HostConfig.Tmpfs.ContainsKey("/var/lib/postgresql")
            || inspect.Mounts.Any(mount => !string.Equals(mount.Type.ToString(), "tmpfs", StringComparison.OrdinalIgnoreCase))
            || inspect.HostConfig.PortBindings.Values.SelectMany(bindings => bindings).Any(binding => binding.HostIP != "127.0.0.1"))
            throw new InvalidOperationException("Exact owned disposable PostgreSQL identity or isolation is unverified.");
        if (inspect.State.Running)
        {
            var ownedConnection = connection ?? new NpgsqlConnectionStringBuilder(postgres.GetConnectionString()) { Pooling = false }.ConnectionString;
            await using var control = new NpgsqlConnection(ownedConnection);
            await control.OpenAsync(cancellation);
            await using var command = new NpgsqlCommand("SELECT count(*) FROM pg_stat_activity WHERE backend_type = 'client backend' AND pid <> pg_backend_pid()", control);
            if (Convert.ToInt64(await command.ExecuteScalarAsync(cancellation)) != 0)
                throw new InvalidOperationException("Owned PostgreSQL still has active local clients.");
        }
    }
}

public sealed class OrdinaryFinancialBoundary : IAsyncDisposable
{
    private const string Role = "roles.legacy.accounting-financial-reader";
    private const string Permission = "legacy.accounting-financial-ownership.read";
    private readonly PermissionService permissions;
    private readonly RoleService roles;
    private readonly PermissionResolver resolver;
    private readonly Microsoft.EntityFrameworkCore.Storage.IDbContextTransaction transaction;
    private readonly object disposalGate = new();
    private Task? disposal;
    public bool PhysicalContextClosed { get; private set; }
    public IAMDbContext Database { get; }
    public PrincipalService Principals { get; }
    public BindingService Bindings { get; }

    public OrdinaryFinancialBoundary(IAMDbContext database)
    {
        Database = database;
        // Every case rolls back its ordinary enrollment and grants; none escapes the owned fixture.
        transaction = database.Database.BeginTransaction();
        var principalRepository = new PrincipalRepository(database);
        var permissionRepository = new PermissionRepository(database);
        var roleRepository = new RoleRepository(database);
        var bindingRepository = new BindingRepository(database);
        var cache = Mock.Of<ICacheService>();
        var audit = Mock.Of<IAuditService>();
        var events = Mock.Of<IPublishEndpoint>();
        Principals = new PrincipalService(principalRepository, Mock.Of<IServiceAccountApiKeyRepository>(), bindingRepository,
            roleRepository, permissionRepository, cache, audit, new ConfigurationBuilder().Build(), NullLogger<PrincipalService>.Instance);
        permissions = new PermissionService(permissionRepository, events, NullLogger<PermissionService>.Instance);
        roles = new RoleService(roleRepository, permissionRepository, cache, audit, events, NullLogger<RoleService>.Instance);
        Bindings = new BindingService(bindingRepository, roleRepository, principalRepository, cache, audit, events,
            NullLogger<BindingService>.Instance);
        resolver = new PermissionResolver(bindingRepository, Principals, cache, NullLogger<PermissionResolver>.Instance);
    }

    public async Task<Principal> EnrollAsync(string client)
    {
        var request = JsonSerializer.Deserialize<RegisterPermissionsRequest>(File.ReadAllText(
            Path.Combine(AppContext.BaseDirectory, "accounting-financial-ownership.json")))!;
        await permissions.RegisterPermissionsAsync(request);
        await roles.RegisterRolesAsync(new RegisterRolesRequest
        {
            ServiceName = "legacy", Roles = [new() { RoleId = Role, Description = "Ordinary financial reader fixture", PermissionIds = [Permission] }]
        });
        // Exactly the existing resolver's derived email convention, never an in-memory alias map.
        return await Principals.CreateAsync("service_account", "service:" + client + "@serviceaccount.maliev.local", null, null);
    }

    public Task<Maliev.IAMService.Application.DTOs.Responses.RoleBindingResponse> GrantAsync(Principal account, string? scope) =>
        Bindings.GrantRoleAsync(account.PrincipalId, new GrantRoleRequest { RoleId = Role, ResourcePath = scope }, account.PrincipalId);

    public Task<Maliev.IAMService.Application.DTOs.Responses.CheckPermissionResponse> CheckAsync(string subject) =>
        resolver.CheckPermissionAsync(new CheckPermissionRequest { PrincipalId = subject, PermissionId = Permission, ResourcePath = "global", BypassCache = true });

    public ValueTask DisposeAsync()
    {
        lock (disposalGate) return new(disposal ??= DisposeCoreAsync());
    }

    private async Task DisposeCoreAsync()
    {
        using var cleanup = new CancellationTokenSource(TimeSpan.FromSeconds(30));
        try { await transaction.RollbackAsync(cleanup.Token); }
        finally
        {
            try { await transaction.DisposeAsync(); }
            finally { await Database.DisposeAsync(); PhysicalContextClosed = true; }
        }
    }
}
