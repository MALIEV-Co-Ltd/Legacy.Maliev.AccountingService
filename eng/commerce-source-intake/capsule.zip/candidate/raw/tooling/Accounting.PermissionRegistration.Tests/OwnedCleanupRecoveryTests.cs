namespace Accounting.PermissionRegistration.Tests;

public sealed class OwnedCleanupRecoveryTests
{
    [Fact]
    public async Task LateOriginalDisposalCanRemoveBackendWhileOriginalQualificationFailureStaysFailed()
    {
        var original = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var closed = false;
        var removed = false;
        var qualification = original.Task.WaitAsync(TimeSpan.FromMilliseconds(1));
        await Assert.ThrowsAsync<TimeoutException>(() => qualification);
        var recovery = new OwnedCleanupRecovery(original.Task, () => closed,
            _ => { Assert.True(closed); return Task.CompletedTask; },
            _ => { Assert.True(closed); removed = true; return Task.CompletedTask; },
            _ => Task.FromResult(removed));
        var physical = recovery.RecoverAsync(TimeSpan.FromSeconds(1));
        Assert.False(removed);
        closed = true;
        original.SetResult();
        await physical;
        Assert.True(removed);
        await Assert.ThrowsAsync<TimeoutException>(() => qualification);
    }

    [Fact]
    public async Task PendingOriginalTaskCannotRemoveBackendAfterRecoveryDeadline()
    {
        var original = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var removed = false;
        var recovery = new OwnedCleanupRecovery(original.Task, () => true, _ => Task.CompletedTask,
            _ => { removed = true; return Task.CompletedTask; }, _ => Task.FromResult(true));
        await Assert.ThrowsAnyAsync<OperationCanceledException>(() => recovery.RecoverAsync(TimeSpan.FromMilliseconds(1)));
        Assert.False(removed);
        original.SetResult();
        await recovery.RecoverAsync(TimeSpan.FromSeconds(1));
        Assert.True(removed);
    }

    [Fact]
    public async Task SettledTaskWithoutPhysicalContextClosureCannotDeleteBackend()
    {
        var removed = false;
        var recovery = new OwnedCleanupRecovery(Task.CompletedTask, () => false, _ => Task.CompletedTask,
            _ => { removed = true; return Task.CompletedTask; }, _ => Task.FromResult(true));
        await Assert.ThrowsAsync<InvalidOperationException>(() => recovery.RecoverAsync(TimeSpan.FromSeconds(1)));
        Assert.False(removed);
    }

    [Fact]
    public async Task ExactOwnerOrIdleCheckFailureCannotDeleteBackend()
    {
        var removed = false;
        var recovery = new OwnedCleanupRecovery(Task.CompletedTask, () => true,
            _ => Task.FromException(new InvalidOperationException("Owner or active-client mismatch")),
            _ => { removed = true; return Task.CompletedTask; }, _ => Task.FromResult(true));
        await Assert.ThrowsAsync<InvalidOperationException>(() => recovery.RecoverAsync(TimeSpan.FromSeconds(1)));
        Assert.False(removed);
    }

    [Fact]
    public async Task UnverifiedBackendAbsenceRemainsFailureAndCanBeRetriedSeparately()
    {
        var absent = false;
        var attempts = 0;
        var recovery = new OwnedCleanupRecovery(Task.CompletedTask, () => true, _ => Task.CompletedTask,
            _ => { attempts++; return Task.CompletedTask; }, _ => Task.FromResult(absent));
        await Assert.ThrowsAsync<InvalidOperationException>(() => recovery.RecoverAsync(TimeSpan.FromSeconds(1)));
        absent = true;
        await recovery.RecoverAsync(TimeSpan.FromSeconds(1));
        Assert.Equal(1, attempts);
    }

    [Fact]
    public async Task LateOriginalBackendDisposalIsAwaitedWithoutStartingASecondDisposalCall()
    {
        var backend = new TaskCompletionSource(TaskCreationOptions.RunContinuationsAsynchronously);
        var calls = 0;
        var absent = false;
        var recovery = new OwnedCleanupRecovery(Task.CompletedTask, () => true, _ => Task.CompletedTask,
            _ => { calls++; return backend.Task; }, _ => Task.FromResult(absent));
        var first = recovery.RecoverAsync(TimeSpan.FromMilliseconds(1));
        await Assert.ThrowsAnyAsync<OperationCanceledException>(() => first);
        var second = recovery.RecoverAsync(TimeSpan.FromSeconds(1));
        Assert.Equal(1, calls);
        Assert.False(second.IsCompleted);
        absent = true;
        backend.SetResult();
        await second;
        Assert.Equal(1, calls);
        Assert.True(first.IsCanceled);
    }

    [Fact]
    public async Task SettledOriginalFaultRequiresPhysicalClosureAndDoesNotTurnQualificationGreen()
    {
        var original = Task.FromException(new InvalidOperationException("Original rollback failed"));
        var removed = false;
        var recovery = new OwnedCleanupRecovery(original, () => true, _ => Task.CompletedTask,
            _ => { removed = true; return Task.CompletedTask; }, _ => Task.FromResult(removed));
        await recovery.RecoverAsync(TimeSpan.FromSeconds(1));
        Assert.True(removed);
        Assert.True(original.IsFaulted);
        await Assert.ThrowsAsync<InvalidOperationException>(() => original);
    }
}
