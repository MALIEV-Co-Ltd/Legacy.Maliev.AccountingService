using System.Text.Json;
using Maliev.IAMService.Application.DTOs.Requests;
using Maliev.IAMService.Application.Interfaces;
using Maliev.IAMService.Application.Services;
using Maliev.IAMService.Domain.Entities;
using MassTransit;
using Microsoft.Extensions.Logging.Abstractions;
using Moq;

namespace Accounting.PermissionRegistration.Tests;

public sealed class FinancialOwnershipRegistrationTests
{
    [Fact]
    public async Task OwnedRequestRegistersExactServiceResourceActionThroughActualIamService()
    {
        var request = ReadRequest();
        Assert.Equal("legacy", request.ServiceName);
        Assert.Equal("legacy.accounting-financial-ownership.read", Assert.Single(request.Permissions).PermissionId);
        var (service, repository, captured) = Create();
        var result = Assert.Single(await service.RegisterPermissionsAsync(request));
        var row = Assert.Single(captured);
        Assert.Equal(request.Permissions[0].PermissionId, row.PermissionId);
        Assert.Equal("legacy", row.ServiceName);
        Assert.Equal("accounting-financial-ownership", row.ResourceType);
        Assert.Equal("read", row.Action);
        Assert.Equal(request.Permissions[0].Description, row.Description);
        Assert.Equal(row.PermissionId, result.PermissionId);
        repository.Verify(value => value.CreateManyAsync(It.IsAny<IEnumerable<Permission>>(), It.IsAny<CancellationToken>()), Times.Once);
    }

    [Theory]
    [InlineData("legacy-accounting")]
    [InlineData("accounting")]
    public async Task MismatchedServiceNameCannotCreateCatalogueRow(string serviceName)
    {
        var (service, repository, captured) = Create();
        Assert.Empty(await service.RegisterPermissionsAsync(ReadRequest() with { ServiceName = serviceName }));
        Assert.Empty(captured);
        repository.Verify(value => value.CreateManyAsync(It.IsAny<IEnumerable<Permission>>(), It.IsAny<CancellationToken>()), Times.Never);
        repository.Verify(value => value.UpdateManyAsync(It.IsAny<IEnumerable<Permission>>(), It.IsAny<CancellationToken>()), Times.Never);
    }

    [Fact]
    public async Task OldFourSegmentPermissionCannotEnterOrdinaryCatalogue()
    {
        var (service, repository, captured) = Create();
        var request = ReadRequest() with
        {
            Permissions = [new() { PermissionId = "legacy.accounting.invoice-financial-ownership.read", Description = "Rejected predecessor" }]
        };
        Assert.Empty(await service.RegisterPermissionsAsync(request));
        Assert.Empty(captured);
        repository.Verify(value => value.CreateManyAsync(It.IsAny<IEnumerable<Permission>>(), It.IsAny<CancellationToken>()), Times.Never);
    }

    private static RegisterPermissionsRequest ReadRequest() =>
        JsonSerializer.Deserialize<RegisterPermissionsRequest>(File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "accounting-financial-ownership.json")))
        ?? throw new InvalidOperationException("Owned request missing.");

    private static (PermissionService Service, Mock<IPermissionRepository> Repository, List<Permission> Captured) Create()
    {
        var repository = new Mock<IPermissionRepository>(MockBehavior.Strict);
        var captured = new List<Permission>();
        repository.Setup(value => value.GetByServiceAsync(It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(Array.Empty<Permission>());
        repository.Setup(value => value.CreateManyAsync(It.IsAny<IEnumerable<Permission>>(), It.IsAny<CancellationToken>()))
            .Callback<IEnumerable<Permission>, CancellationToken>((rows, _) => captured.AddRange(rows)).Returns(Task.CompletedTask);
        return (new PermissionService(repository.Object, Mock.Of<IPublishEndpoint>(), NullLogger<PermissionService>.Instance), repository, captured);
    }
}
