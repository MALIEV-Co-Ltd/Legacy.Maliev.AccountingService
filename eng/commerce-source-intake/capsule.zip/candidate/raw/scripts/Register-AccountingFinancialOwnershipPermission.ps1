[CmdletBinding()]
param(
    [Parameter(Mandatory)][uri] $IamOrigin,
    [Parameter(Mandatory)][securestring] $AccessToken
)

$ErrorActionPreference = 'Stop'
if ($IamOrigin.Scheme -ne 'https' -or !$IamOrigin.Host -or $IamOrigin.UserInfo -or
    $IamOrigin.AbsolutePath -ne '/' -or $IamOrigin.Query -or $IamOrigin.Fragment) {
    throw 'An explicit HTTPS IAM origin without credentials, path, query or fragment is required.'
}
$path = Join-Path $PSScriptRoot '../provisioning/iam/accounting-financial-ownership.json'
$body = [IO.File]::ReadAllText($path)
$catalogue = $body | ConvertFrom-Json
if ($catalogue.ServiceName -cne 'legacy' -or @($catalogue.Permissions).Count -ne 1 -or
    $catalogue.Permissions[0].PermissionId -cne 'legacy.accounting-financial-ownership.read' -or
    $catalogue.Permissions[0].Description -cne 'Read immutable invoice creation financial ownership for authorized service callers.' -or
    @($catalogue.PSObject.Properties.Name).Count -ne 2 -or
    @($catalogue.Permissions[0].PSObject.Properties.Name).Count -ne 2) {
    throw 'The owned catalogue registration request does not match the approved contract.'
}

# Explicit administrative provisioning only. Never called from application startup.
# The existing IAM endpoint enforces iam.permissions.create; this script adds no bindings or roles.
$handler = [Net.Http.HttpClientHandler]::new()
$handler.AllowAutoRedirect = $false
$client = [Net.Http.HttpClient]::new($handler)
$client.Timeout = [TimeSpan]::FromSeconds(30)
$request = [Net.Http.HttpRequestMessage]::new([Net.Http.HttpMethod]::Post,
    [uri]::new($IamOrigin, 'iam/v1/permissions/register'))
$response = $null
$pointer = [IntPtr]::Zero
try {
    $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($AccessToken)
    $request.Headers.Authorization = [Net.Http.Headers.AuthenticationHeaderValue]::new('Bearer',
        [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer))
    $request.Content = [Net.Http.StringContent]::new($body, [Text.Encoding]::UTF8, 'application/json')
    $response = $client.SendAsync($request).GetAwaiter().GetResult()
    if ([int]$response.StatusCode -ne 200) { throw "IAM catalogue registration failed with HTTP $([int]$response.StatusCode)." }
    $rows = $response.Content.ReadAsStringAsync().GetAwaiter().GetResult() | ConvertFrom-Json
    $owned = @($rows | Where-Object { $_.PermissionId -ceq 'legacy.accounting-financial-ownership.read' })
    if ($owned.Count -ne 1 -or $owned[0].ServiceName -cne 'legacy' -or
        $owned[0].ResourceType -cne 'accounting-financial-ownership' -or $owned[0].Action -cne 'read') {
        throw 'IAM did not return the exact owned catalogue row; no permission grant is inferred.'
    }
    [pscustomobject]@{ PermissionId = $owned[0].PermissionId; CatalogueRegistered = $true; PrincipalGrantsCreated = $false }
}
finally {
    if ($pointer -ne [IntPtr]::Zero) { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer) }
    if ($null -ne $response) { $response.Dispose() }
    $request.Dispose()
    $client.Dispose()
}
