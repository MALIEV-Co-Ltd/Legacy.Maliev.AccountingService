"""Synthetic parser controls only; never native employee or database acceptance."""
import contextlib
import copy
import io
import json
from pathlib import Path
import runpy
import sys
import tempfile
import unittest
import uuid
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = json.loads((ROOT / 'employee-completion-expected.json').read_text())
METHOD = 'Legacy.Maliev.AccountingService.Tests.InvoiceFinancialOwnershipHttpTests.GranularGrantNeverSubstitutesForExactReaderIdentity'
NS = 'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'


class EmployeeInventoryControls(unittest.TestCase):
    def invoke(self, full=False, predecessor=False, skip=False):
        with tempfile.TemporaryDirectory(prefix='accounting-employee-parser-') as temporary:
            root = Path(temporary)
            inventory = copy.deepcopy(MANIFEST['methods'])
            if predecessor:
                inventory[METHOD] -= 1
            count = sum(inventory.values())
            if full:
                inventory['Synthetic.Other.FullSuite'] = MANIFEST['fullForecast'] - count
            count = sum(inventory.values())
            tag = lambda name: '{' + NS + '}' + name
            run = ET.Element(tag('TestRun'))
            definitions = ET.SubElement(run, tag('TestDefinitions'))
            results = ET.SubElement(run, tag('Results'))
            for method, cases in inventory.items():
                class_name, name = method.rsplit('.', 1)
                for case in range(cases):
                    test_id, execution_id = str(uuid.uuid4()), str(uuid.uuid4())
                    display = method + '(' + str(case) + ')'
                    unit = ET.SubElement(definitions, tag('UnitTest'), id=test_id, name=display)
                    ET.SubElement(unit, tag('TestMethod'), className=class_name, name=name)
                    ET.SubElement(unit, tag('Execution'), id=execution_id)
                    ET.SubElement(results, tag('UnitTestResult'), testId=test_id, executionId=execution_id,
                                  testName=display, outcome='NotExecuted' if skip else 'Passed')
            summary = ET.SubElement(run, tag('ResultSummary'), outcome='Completed')
            counters = {key: str(count) for key in ['total', 'executed', 'passed']}
            counters.update({key: '0' for key in ['failed', 'error', 'timeout', 'aborted', 'inconclusive',
                            'passedButRunAborted', 'notRunnable', 'notExecuted', 'disconnected', 'warning',
                            'completed', 'inProgress', 'pending']})
            ET.SubElement(summary, tag('Counters'), counters)
            ET.ElementTree(run).write(root / 'synthetic.trx', encoding='utf-8')
            coverage = '<coverage><packages>' + ''.join(
                '<package name="Legacy.Maliev.AccountingService.' + name + '"><classes><class><lines>'
                '<line number="1" hits="1" /></lines></class></classes></package>'
                for name in ['Api', 'Application', 'Data', 'Domain']) + '</packages></coverage>'
            for directory in ['raw1', 'raw2']:
                (root / directory).mkdir()
                (root / directory / 'coverage.cobertura.xml').write_text(coverage)
            previous = sys.argv
            try:
                sys.argv = [str(ROOT / 'verify-employee-completion.py'), str(root)] + (['--full'] if full else [])
                with contextlib.redirect_stdout(io.StringIO()):
                    runpy.run_path(str(ROOT / 'verify-employee-completion.py'), run_name='__main__')
                return json.loads((root / 'employee-completion-proof.json').read_text())
            finally:
                sys.argv = previous

    def test_exact_manifest_tracks_seventeen_denials_and_169_cases(self):
        self.assertEqual(17, MANIFEST['methods'][METHOD])
        self.assertEqual(169, sum(MANIFEST['methods'].values()))
        self.assertEqual(169, MANIFEST['forecast'])
        self.assertEqual(1671, MANIFEST['fullForecast'])

    def test_actual_verifier_accepts_synthetic_169_and_reports_169_employee(self):
        proof = self.invoke()
        self.assertEqual(169, proof['actualPassed'])
        self.assertEqual(169, proof['employeeActualPassed'])
        self.assertFalse(proof['actualProducerJoinProven'])

    def test_actual_verifier_accepts_synthetic_1671_with_exact_employee_subset(self):
        proof = self.invoke(full=True)
        self.assertEqual(1671, proof['actualPassed'])
        self.assertEqual(169, proof['employeeActualPassed'])

    def test_predecessor_168_inventory_is_rejected(self):
        with self.assertRaises(SystemExit):
            self.invoke(predecessor=True)

    def test_full_count_cannot_hide_missing_seventeenth_case(self):
        with self.assertRaises(SystemExit):
            self.invoke(full=True, predecessor=True)

    def test_nonpassing_results_remain_rejected(self):
        with self.assertRaises(SystemExit):
            self.invoke(skip=True)


if __name__ == '__main__':
    unittest.main()
